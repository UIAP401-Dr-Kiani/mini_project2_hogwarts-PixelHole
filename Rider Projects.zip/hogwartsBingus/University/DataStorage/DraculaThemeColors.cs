using System.Windows.Media;

namespace hogwartsBingus.DataStorage
{
    public static class DraculaThemeColors
    {
        public static readonly Color Green = Color.FromRgb(80, 250, 123);
        public static readonly Color Red = Color.FromRgb(255, 85, 85);
    }
}