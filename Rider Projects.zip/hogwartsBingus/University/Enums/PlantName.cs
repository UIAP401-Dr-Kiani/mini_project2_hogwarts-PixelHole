namespace hogwartsBingus.Base_Classes
{
    public enum PlantName
    {
        FoolsParsley = 0,
        Mandrake = 1,
        Dittany = 2,
        DevilsSnare = 3,
        Alihotsy = 4,
        Asphodel = 5,
        WolfsBane = 6,
        Flutterby = 7,
        Balm = 8, 
        AloeVera = 9
    }
}