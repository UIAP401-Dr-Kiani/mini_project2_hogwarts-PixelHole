namespace hogwartsBingus.Base_Classes
{
    public enum petType
    {
        Rat = 0,
        Cat = 1,
        Owl = 2,
        OwlBear = 3,
    }
}