namespace hogwartsBingus.Base_Classes
{
    public enum AuthorizationType
    {
        Student = 0,
        Professor = 1,
        Dumbledore = 2
    }
}