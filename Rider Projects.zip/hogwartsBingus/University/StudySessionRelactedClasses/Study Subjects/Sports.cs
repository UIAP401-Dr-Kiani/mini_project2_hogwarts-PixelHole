namespace hogwartsBingus.Base_Classes.Study_Subjects
{
    public class Sports : StudySubject
    {
        
    }
}