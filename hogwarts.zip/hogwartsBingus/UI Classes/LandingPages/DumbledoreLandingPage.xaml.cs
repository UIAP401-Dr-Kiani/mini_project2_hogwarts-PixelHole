using System.Windows;

namespace hogwartsBingus.UI_Classes
{
    public partial class DumbledoreLandingPage : Window
    {
        public DumbledoreLandingPage()
        {
            InitializeComponent();
        }
    }
}