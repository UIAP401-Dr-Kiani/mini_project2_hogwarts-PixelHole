namespace hogwartsBingus.Base_Classes
{
    public enum FactionType
    {
        Slytherin = 0,
        Raveclaw = 1,
        Hufflepuff = 2,
        Gryffindor = 3,
        None = -1
    }
}