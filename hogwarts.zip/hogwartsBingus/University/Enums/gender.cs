namespace hogwartsBingus.Base_Classes
{
    public enum gender
    {
        Male = 0,
        Female = 1
    }
}