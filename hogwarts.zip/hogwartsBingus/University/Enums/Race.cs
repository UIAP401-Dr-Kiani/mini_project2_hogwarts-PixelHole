namespace hogwartsBingus.Base_Classes
{
    public enum Race
    {
        Half_Blood = 0,
        Pure_Blood = 1,
        Muggle = 2,
        Normal = 2
    }
}